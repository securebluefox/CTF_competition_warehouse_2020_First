#!/usr/bin/env python3
# -*- coding: utf-8 -*-

class Cipher:

    MASK = 0xffffffff
    POLYNOMIAL_PX = 0x8ce56011
    POLYNOMIAL_PA0 = 0xdb710641
    POLYNOMIAL_PA1 = 0xc3e887e1
    POLYNOMIAL_PB = 0xa4031803

    def __init__(self, key, inits):
        self.L = self.initL(key)
        self.X = inits[0]
        self.A = inits[1]
        self.B = inits[2]

    def bchr(self, i):
        return bytes([i])

    def genKeystream(self, N):
        keystreamByte = b''
        for i in range(N):
            self.step()

            c = (self.L[self.high(self.A)] 
                 + self.L[self.high(self.B)] 
                 + self.high(self.X)
                 ) & 0xff

            keystreamByte += self.bchr(c)
        
        return keystreamByte

    def poppar(self, t):
        t ^= (t >> 16)
        t ^= (t >> 8)
        t ^= (t >> 4)
        t ^= (t >> 2)
        t ^= (t >> 1) & 0x1
        return t

    def stepX(self):
        t = self.X & self.POLYNOMIAL_PX

        t = self.poppar(t)

        X = (self.X >> 1) | (t << 31)
        self.X = X & self.MASK

    def stepA(self):
        x = ((self.X & 0x4) >> 2) & 0x1

        if x == 0:
            t = self.A & self.POLYNOMIAL_PA0
        else:
            t = self.A & self.POLYNOMIAL_PA1

        t = self.poppar(t)

        A = (self.A >> 1) | (t << 31)
        self.A = A & self.MASK

    def stepB(self):
        x = ((self.X & 0x20) >> 5) & 0x1

        for _ in range(x + 1):
            t = self.B & self.POLYNOMIAL_PB

            t = self.poppar(t)

            B = (self.B >> 1) | (t << 31)
            self.B = B & self.MASK

    def step(self):
        self.stepX()
        self.stepA()
        self.stepB()

    def initL(self, key):
        l = len(key)
        K = [key[i % l] for i in range(256)]
        S = list(range(256))

        j = 0
        for i in range(256):
            j = (j + S[i] + K[i]) & 0xff
            S[i], S[j] = S[j], S[i]
        
        return S

    def high(self, X):
        return (X & 0xff)


if __name__ == "__main__":
    import uuid
    from hashlib import sha256
    from secret import key, flag

    raw_flag = uuid.uuid3(
        uuid.NAMESPACE_DNS, 
        key.decode('latin-1'))

    assert len(key) == 12
    assert sha256(key).hexdigest()[:10] == 'eb2a2b4cad'
    assert flag == "flag{{{}}}".format(raw_flag)


    inits = [int.from_bytes(key[4*i : 4*(i+1)], 'big') 
             for i in range(3)]
    cipher = Cipher(b"^ORXY$", inits)

    ks = cipher.genKeystream(0x20)
    print(ks.hex())

    # e53d1c5c4e1d7e38e3f51f45f8c955fc54b1a186f52ecc450328531139b71a7e


