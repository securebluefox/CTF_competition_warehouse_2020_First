#!/usr/bin/env python
import os, random, sys, string
from hashlib import sha256

from flag import FLAG

SZ = 8

def gbox(a,b,mode):
    x = (a+b+mode)%256
    return ((x<<2)|(x>>6))&0xff

def fbox(plain):
    t0 = (plain[3] ^ plain[0])
    y1 = gbox(plain[1] ^ plain[2], t0, 1)
    y0 = gbox(plain[1], y1, 0)
    y2 = gbox(t0, y1, 0)
    y3 = gbox(plain[0], y2, 1)
    return [y3, y0, y1, y2]


def doxor(m,n):
    return map(lambda x: x[0]^x[1], zip(m, n))


def encrypt_block(pt, ks):
    l = doxor(pt[:4], ks[4])
    r = doxor(pt[4:], ks[5])
    for i in range(4):
        l, r = doxor(l, fbox(doxor(r, ks[i]))), r
        l, r = doxor(l, r), l

    return l+r

def encrypt(pt, k):
    x = (SZ-len(pt)) % SZ
    pt += chr(x)*x
    ct = ''
    for i in range(0, len(pt), SZ):
        res = encrypt_block(map(ord, pt[i:i+SZ]), k)
        ct += ''.join(map(chr, res))
    return ct

def doout(x):
    tmp = ''.join(map(chr, x))
    return tmp.encode('hex')

def genkeys():
    subkeys=[]
    for x in xrange(6):
        subkeys.append(map(ord, os.urandom(4)))
    return subkeys


def recvhex():
    try:
        res = ''
        res += raw_input()
        res = res.strip()
        print(res)
        res = res.decode('hex')
    except:
        res = ''
    return res


def main():
    key = genkeys()
    for i in xrange(48):
        print("plaintext(hex): ")
        pt = recvhex()
        if pt == '':
            break
        ct = encrypt(pt, key)
        print("%s" % ct.encode('hex'))
    cflag = encrypt(FLAG, key)
    print("and your flag:")
    print("%s" % cflag.encode('hex'))


if __name__ == "__main__":
    main()