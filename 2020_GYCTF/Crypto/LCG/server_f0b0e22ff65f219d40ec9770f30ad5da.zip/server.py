#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socketserver
import os, signal
import threading
import string, binascii
from hashlib import sha256

from Crypto.Util import number
from Crypto.Random import random, atfork

from secret import FLAG


class Task(socketserver.BaseRequestHandler):

    _key = None
    _rand_iter = None

    def _recvall(self):
        BUFF_SIZE = 2048
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data.strip()

    def send(self, msg, newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def recv(self, prompt=b'> '):
        self.send(prompt, newline=False)
        return self._recvall()

    def proof_of_work(self):
        proof = ''.join(
                    [ random.choice(string.ascii_letters+string.digits) for _ in range(20) ]
                    )
        _hexdigest = sha256( proof.encode() ).hexdigest()
        self.send(str.encode( "sha256(XXXX+%s) == %s" % (proof[4:], _hexdigest) ))
        x = self.recv(prompt=b'Give me XXXX: ')

        if len(x) != 4 or sha256(x+proof[4:].encode()).hexdigest() != _hexdigest:
            return False
        return True

    def timeout_handler(self, signum, frame):
        self.send(b"\n\nSorry, time out.\n")
        raise TimeoutError

    def lcg(self, seed, params):
        (a, b, m) = params

        x = seed % m
        while True:
            x = (a*x + b) % m
            yield x

    def genDSA(self):
        q = number.getPrime(160)

        while True:
            X = random.getrandbits(1024)
            c = X % (q * 2)
            p = X - (c - 1)
            if number.isPrime(p) and p.bit_length()==1024:
                break

        e = (p - 1) // q
        h = 2
        g = pow(h, e, p)

        c = random.getrandbits(160)
        x = c % (q - 1) + 1
        y = pow(g, x, p)

        self._key = { 'y':y, 'g':g, 'p':p, 'q':q, 'x':x }

    def send_params(self, **params):
        for kw in params:
            self.send(str.encode(f"{kw} = {params[kw]}"))

    def _sign(self, m):
        if not self._key:
            raise ValueError("[*] DSA key is None")

        k = next(self._rand_iter)
        if not (1 < k < self._key['q']):
            raise ValueError("[*] k is not between 2 and q-1")

        x, q, p, g = [self._key[comp] for comp in ['x', 'q', 'p', 'g']]

        k_inv = number.inverse(k, q)

        r = pow(g, k, p) % q
        s = (k_inv * (m + x * r)) % q
        return map(int, (r, s))

    def _verify(self, m, sig):
        r, s = sig
        y, q, p, g = [self._key[comp] for comp in ['y', 'q', 'p', 'g']]
        if not (0 < r < q) or not (0 < s < q):
            return False

        w = number.inverse(s, q)
        u1 = int((w * m) % q)
        u2 = int((w * r) % q)
        v = (pow(g, u1, p) * pow(y, u2, p) % p) % q

        return v == r

    def _is_valid_name(self, name):
        if not (0 < len(name) <= 20):
            raise ValueError("[*] name length inappropriate")

        for c in name:
            if c not in string.printable.encode():
                raise ValueError("[*] name is unprintable")

        if name == b'admin':
            raise ValueError("[*] name is equal to 'admin'")

        return True

    def sign_up(self, name):
        if not self._is_valid_name(name):
            return None

        m = int.from_bytes(name, 'big')
        sig = self._sign(m)

        return sig


    def sign_in(self, data):
        assert (40 < len(data) <= 60), "signature wrong length"

        (name, r, s) = (data[:-40], data[-40:-20], data[-20:])
        m, *sig = map(lambda x: int.from_bytes(x, 'big'), (name, r, s))

        if not self._verify(m, sig):
            raise ValueError("Wrong signature")

        return name

    def handle(self):
        atfork()

        try:
            signal.signal(signal.SIGALRM, self.timeout_handler)
            signal.alarm(60)

            daemon_thread = threading.Thread(target=self.genDSA, daemon=True)
            daemon_thread.start()

            if not self.proof_of_work():
                return

            daemon_thread.join()

            self.send_params(p = self._key['p'],
                             q = self._key['q'],
                             g = self._key['g'],
                             y = self._key['y'])

            seed = random.getrandbits(160)
            a = self._key['y'] * 233333 % self._key['q']
            b = self._key['y'] * 0x2333 % self._key['q']
            m = self._key['q']
            self._rand_iter = self.lcg(seed, (a,b,m))

            for _ in range(16):
                command = self.recv(prompt=b'$ ')

                if not command:
                    break

                if command == b'sign up':
                    self.send(b'Give me your username')
                    name = self.recv()
                    (r, s) = self.sign_up(name)
                    sig = name + r.to_bytes(20, 'big') + s.to_bytes(20, 'big')
                    self.send(b'Here is your signature(hex)')
                    self.send(sig.hex().upper().encode())

                elif command == b'sign in':
                    self.send(b'Give me your signature(hex)')
                    hex_data = self.recv()
                    data = binascii.unhexlify(hex_data)
                    name = self.sign_in(data)
                    self.send(str.encode(f"Welcome, {name.decode()}."))
                    if name == b"admin":
                        self.send(str.encode(f"The flag is {FLAG}."))

                else:
                    break

            self.send(b'Bye~~')
            self.request.close()

        except:
            pass


class ForkedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass

if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 1234
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()
