./emulator ./test.bin
