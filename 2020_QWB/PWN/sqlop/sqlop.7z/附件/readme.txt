系统环境：Ubuntu 20.04.1 LTS (GNU/Linux 5.4.0-42-generic x86_64)

上传的db文件会被重命名然后作为参数输入到sqlite3中解析10次，stdout会被显示到web页面中

flag在/flag，可通过cat flag直接读取

直接执行指令的方式为：./sqlite3 malicious.db < cmd （cmd中为固定内容，选手不可控制）

服务器端会使用chroot执行该指令，环境变量可能会影响堆的layout，请本地成功但远程不成功的选手可以尝试修改一些offset。