#encoding:utf-8
import socket
import struct
import multiprocessing
import random
from hashlib import md5, sha256

IP = "xxx.xxx.xxx.xxx"
PORT = 10235

def GetSalt(data):
    return int((md5(sha256(data.encode()).digest())).hexdigest(), 16) % 256

def encrypt(data, btime, count):
    funcs = {
        "0" : lambda x, y : x - y,
        "1" : lambda x, y : x + y,
        "2" : lambda x, y : x ^ y
    }

    offset = {
        "0" : 0xefffff,
        "1" : 0xefffff,
        "2" : 0xffffff,
    }
    length = len(data) + 10
    fn = str(random.randint(0, 65535) % 3).encode()
    salt = GetSalt(data) 

    t = struct.unpack("<i", btime)[0]
    boffset = offset[fn.decode()]
    t -= boffset
    t = struct.pack("<i", t)

    enc = struct.pack("<IIcB", count, length, fn, salt)
    i = 0 
    for c in data:
        enc += chr((funcs[fn.decode()](ord(c) ^ ord(t[i]), salt) % 256))
        i = (i + 1) % 4

    return boffset, enc


def SendMessage(ClientSocket):
    f = open("data.txt", "r")
    readlines = f.readlines()
    f.close()
    count = 0

    for readline in readlines:
        try:
            ClientSocket.send("G")

            btime = ClientSocket.recv(4)

            boffset, data = encrypt(readline, btime, count)
            ClientSocket.send(struct.pack("<i", boffset))
            ClientSocket.send(data)
            pcount = struct.unpack("<i", ClientSocket.recv(4))[0]
            count += 1
            if pcount != count:
                print("error!")
                break
        except:
            print("error!")
            break
    ClientSocket.close()


if __name__ == '__main__':
    ClientSocket = socket.socket(family = socket.AF_INET, type = socket.SOCK_STREAM)
    ClientSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    ClientSocket.connect((IP,PORT))

    SendMessage(ClientSocket)

    ClientSocket.close()
