import signal
import random
import os
import time
import string
import hashlib
from flag import getflag

def get_user_input(s):
    try:
        data = bytes.fromhex(input(s))
    except:
        print("Invalid input format")
        exit(0)
    return data

def proof():
    difficulty = 24
    prefix = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(8))
    answer = get_user_input(f"sha256('{prefix}'+ ? ).binary.startswith('0'*{difficulty}): ")
    hashresult=hashlib.sha256(prefix.encode()+answer).digest()
    bits=''.join(bin(_)[2:].zfill(8) for _ in hashresult)
    if not bits.startswith('0'*difficulty):
        exit(0)

signal.alarm(15)
proof()
flag = getflag(get_user_input("Input your team token: ").decode())

signal.alarm(10)
random.seed(int(time.time()))
random_constants = [random.randint(0, 2**32 - 1) for i in range(64)]
random_iv = [random.randint(0, 2**32 - 1) for i in range(4)]

def left_rotate(x, amount):
    x &= 0xFFFFFFFF
    return ((x<<amount) | (x>>(32-amount))) & 0xFFFFFFFF

def random_hash(message):
    rotate_amounts = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
                      5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20,
                      8, 11, 16, 23, 8, 11, 16, 23, 8, 11, 16, 23, 8, 11, 16, 23,
                      6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21]

    functions = 16*[lambda b, c, d: (b & c) | (~b & d)] + \
                16*[lambda b, c, d: (d & b) | (~d & c)] + \
                16*[lambda b, c, d: b ^ c ^ d] + \
                16*[lambda b, c, d: c ^ (b | ~d)]

    index_functions = 16*[lambda i: i] + \
                      16*[lambda i: (5*i + 1)%16] + \
                      16*[lambda i: (3*i + 5)%16] + \
                      16*[lambda i: (7*i)%16]

    message = bytearray(message)
    orig_len_in_bits = (8 * len(message)) & 0xffffffffffffffff
    message.append(0x80)
    while len(message)%64 != 56:
        message.append(0)
    message += orig_len_in_bits.to_bytes(8, 'little')

    hash_pieces = random_iv[:]

    for chunk_ofst in range(0, len(message), 64):
        a, b, c, d = hash_pieces
        chunk = message[chunk_ofst:chunk_ofst+64]
        for i in range(64):
            f = functions[i](b, c, d)
            g = index_functions[i](i)
            to_rotate = a + f + random_constants[i] + int.from_bytes(chunk[4*g:4*g+4], 'little')
            a, b, c, d = d, (b + left_rotate(to_rotate, rotate_amounts[i])) & 0xFFFFFFFF, b, c
        for i, val in enumerate([a, b, c, d]):
            hash_pieces[i] += val
            hash_pieces[i] &= 0xFFFFFFFF

    return sum(x<<(32*i) for i, x in enumerate(hash_pieces)).to_bytes(16, "little")

def isPrime(n):
    r, s = 0, n - 1
    while s % 2 == 0:
        r += 1
        s //= 2
    for _ in range(20):
        a = random.randrange(2, n - 1)
        x = pow(a, s, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def randprime():
    p = int.from_bytes(os.urandom(64), "little")
    p -= (p%2) - 1
    while not isPrime(p):
        p += 2
    return p

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

def modinv(a, m):
    g, x, y = egcd(a, m)
    if g != 1:
        return 0
    else:
        return x % m

e = 65537
p = randprime()
q = randprime()
N = p*q
print(f"pubkey = ({N}, {e})")
phi = (p-1)*(q-1)
d = modinv(e, phi)

def sign(data):
    return pow(int.from_bytes(random_hash(data), "little"), d, N).to_bytes(128, "little")

def verify(data, sig):
    return pow(int.from_bytes(sig, "little"), e, N) == int.from_bytes(random_hash(data), "little")

def unserialize_data(userdata):
    if userdata[:3] != b"QWB":
        return '', 0
    offset = 3
    name = ''
    perm = 0
    while offset < len(userdata):
        length = int.from_bytes(userdata[offset+1:offset+3], "little")
        data = userdata[offset+3:offset+3+length]
        if userdata[offset] == 0xFF:
            perm = int.from_bytes(data, "little")
        elif userdata[offset] == 0xCC:
            name = data
        else:
            return '', 0
        offset += 3 + length
    return name, perm

def serialize_data(username, permission):
    return b"QWB"  + \
           b"\xFF" + b"\x01\x00"                         + permission.to_bytes(1, "little") + \
           b"\xCC" + len(username).to_bytes(2, "little") + username

def login():
    userdata = get_user_input("Give me your secret login token: ")
    sig = userdata[:128]
    userdata = userdata[128:]
    if verify(userdata, sig):
        username, permission = unserialize_data(userdata)
        if permission == 0xFF:
            print(f"{flag}")
        else:
            print(f"Welcome {username.decode()}!")
    else:
        print("Wrong login token, please register first.")

def reg():
    username = get_user_input("Give me your name: ")
    userdata = serialize_data(username, 0)
    userdata = sign(userdata) + userdata
    print(f"Here's your login token: {userdata.hex()}")

while True:
    if get_user_input("Register? ") == b'\x00':
        reg()
    else:
        login()