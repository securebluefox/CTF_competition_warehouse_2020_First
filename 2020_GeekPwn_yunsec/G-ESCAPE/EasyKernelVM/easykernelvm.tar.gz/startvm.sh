#!/bin/sh


timeout --foreground 600 ./qemu-system-x86_64 \
	-kernel ./kernel-guest -initrd ./initramfs.img \
	-m 64M -append 'console=ttyS0 rdinit=/linuxrc loglevel=3 oops=panic panic=1 kaslr'  \
	--nographic -enable-kvm -L ./pc-bios
