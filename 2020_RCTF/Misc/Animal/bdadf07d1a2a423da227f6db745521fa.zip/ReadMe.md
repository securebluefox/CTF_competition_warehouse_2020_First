# ReadMe

Tom Nook sent a telegram from the uninhabited island welcoming the new residents. It's not fish sauce, it's bass.