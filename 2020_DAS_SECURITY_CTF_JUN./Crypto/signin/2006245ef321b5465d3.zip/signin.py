import binascii
import base64
import random

from data import g, p, x, h, flag
from Crypto.Util.number import bytes_to_long, long_to_bytes, GCD, inverse


def xgcd(b, n):
    x0, x1, y0, y1 = 1, 0, 0, 1
    while n != 0:
        q, b, n = b // n, n, b % n
        x0, x1 = x1, x0 - q * x1
        y0, y1 = y1, y0 - q * y1
    return b, x0, y0


def modinv(b, n):
    g, x, _ = xgcd(b, n)
    if g == 1:
        return x % n


def sign(m, sk, p, g):
    assert len(bin(m)) < len(bin(p))
    while True:
        k = random.SystemRandom().randint(0, p-1)
        if GCD(k, p-1) == 1:
            break
    r = pow(g, k, p)
    s = (m - sk * r) % (p-1)
    while s < 0:
        s += (p-1)
    s = (s * inverse(k, p-1)) % (p-1)
    return r, s


def verify(m, r, s, y, p, g):
    m = bytes_to_long(bytes(m.encode()))
    if r < 1:
        return False
    if (pow(y, r, p) * pow(r, s, p)) % p == pow(g, m, p):
        return True
    return False


def dec(c1, c2):
    s = pow(c1, x, p)
    M = (c2 * modinv(s, p)) % p

    return long_to_bytes(M)


def login():
    c = input('Please input your access token: ')
    c = c.split('_')
    user = input('Please input your username: ')
    message = input('Please input your message: ')
    r = int(c[0], 16)
    s = int(c[1], 16)
    if verify(user + '#' + message, r, s, h, p, g):
        if user == 'admin':
            print('Here\'s your flag: {}'.format(flag))
    print('That\'s all, nothing else happening here.')


def register():
    username = input('Your username: ')
    message = input('Your message: ')

    if username == 'admin':
        print('[-] no, i know you are not admin')
        return
    m = username + '#' + message
    r, s = sign(bytes_to_long(bytes(m.encode())), x, p, g)
    token = '{:x}_{:x}'.format(r, s)
    print('Here is your access token:\n{}'.format(token))


if __name__ == '__main__':
    banner = '''
               .__                                  __
__  _  __ ____ |  |   ____  ____   _____   ____   _/  |_  ____
\ \/ \/ // __ \|  | _/ ___\/  _ \ /     \_/ __ \  \   __\/  _ \
 \     /\  ___/|  |_\  \__(  <_> )  Y Y  \  ___/   |  | (  <_> )
  \/\_/  \___  >____/\___  >____/|__|_|  /\___  >  |__|  \____/
             \/          \/            \/     \/
                             __                               .__       .___
  ___________ ___.__._______/  |_  ____   __  _  _____________|  |    __| _/
_/ ___\_  __ <   |  |\____ \   __\/  _ \  \ \/ \/ /  _ \_  __ \  |   / __ |
\  \___|  | \/\___  ||  |_> >  | (  <_> )  \     (  <_> )  | \/  |__/ /_/ |
 \___  >__|   / ____||   __/|__|  \____/    \/\_/ \____/|__|  |____/\____ |
     \/       \/     |__|                                                \/
    '''
    print(banner)
    print('we are using', p, h, 'as p and h is time')
    while True:
        try:
            print('[+] there are serval choices you can choose')
            print('[1] Login')
            print('[2] Register')
            print('[3] Exit')
            choice = input('> ')
            if str(choice) == '1':
                login()
            elif str(choice) == '2':
                register()
            elif str(choice) == '3':
                print('[+] Bye...')
                break
        except Exception:
            continue
