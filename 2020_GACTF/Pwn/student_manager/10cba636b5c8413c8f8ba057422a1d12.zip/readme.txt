运行时确保libc与附件里的一模一样，否则程序会崩溃。

#when run the program,you must make sure the libc is same as we provided or it will probably crash.
