#![no_std]

extern crate code;

use code::code;
fn main() {
    let _flag = {};
    code();
}
