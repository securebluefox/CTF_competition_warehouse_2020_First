from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField
from wtforms.validators import DataRequired, Length, ValidationError
import requests

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    master_key = PasswordField('Master_key', validators=[DataRequired(), Length(min=8, message='key length >= 8!')])
    submit = SubmitField('Submit')

    def validate_username(self, field):
        res = requests.post('http://kdc:5001/check_username', data={'username': field.data})
        if res.content == '1':
            raise ValidationError('Username already in use')

class CmdForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    master_key = PasswordField('Master_key', validators=[DataRequired(), Length(min=8, message='key length >= 8!')])
    cmd = StringField('Cmd', validators=[DataRequired()], default='whoami')
    submit = SubmitField('Submit')

    def validate_username(self, field):
        res = requests.post('http://kdc:5001/check_username', data={'username': field.data})
        if res.content == '0':
            raise ValidationError('Username Not Exsist')