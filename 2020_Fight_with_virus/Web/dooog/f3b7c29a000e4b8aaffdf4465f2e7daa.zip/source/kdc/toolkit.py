from Crypto.Cipher import AES
from Crypto import Random
import hashlib

BS = 16

def unicode_to_utf8(s):
    if isinstance(s, unicode):
        s = s.encode("utf-8")
    return s
 

def pad(s):
    length = len(s)
    add = BS - length % BS
    byte = chr(BS - length % BS)
    return s + (add * byte)
 

def unpad(s):
    length = len(s)
    byte = s[length-1:]
    add = ord(byte)
    return s[:-add]
 
 
class AESCipher:
    def __init__(self, key):
        self.key = hashlib.md5(key).hexdigest()
 
    def encrypt(self, raw):
        raw = unicode_to_utf8(raw)
        raw = pad(raw)
        cipher = AES.new(self.key, AES.MODE_CBC, 'HaHaHahahahahaha')
        return cipher.encrypt(raw)
 
    def decrypt(self, enc):
        cipher = AES.new(self.key, AES.MODE_CBC, 'HaHaHahahahahaha')
        return unpad(cipher.decrypt(enc))