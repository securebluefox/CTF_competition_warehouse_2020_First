from Crypto.Util.number import *
from functools import reduce

def genKey(length):
    A, B = getPrime(64), getPrime(1025)

    Rn = getPrime(1024)
    key1 = [Rn//2**i for i in range(1, length+1)]
    key2 = [i*A % B for i in key1]
    return key1,key2


def encrypt(text,key):
    Sum=0
    for i in range(len(text)):
        Sum+=int(text[i])*key[i]
    return Sum

def save(Ciper,Key):
    f1=open("pub.txt","w")
    for i in range(len(Key)):
        f1.write(str(Key[i])+'\n')
    f2=open("cip.txt","w")
    f2.write(hex(Ciper))


FLAG = bin(bytes_to_long(flag.encode()))[2:]
Key1,Key2 = genKey(len(FLAG))
Ciper = encrypt(FLAG,Key1)
save(Ciper,Key2)
