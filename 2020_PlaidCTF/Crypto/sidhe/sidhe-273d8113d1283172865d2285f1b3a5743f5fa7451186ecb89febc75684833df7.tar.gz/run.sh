python3 pow.py && sage server.sage
