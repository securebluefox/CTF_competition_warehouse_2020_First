Username：
09AF6EECF24F47CA
Key:
E247EC9C06C71B6E13

目标：找到用户名"KCTF"对应的Key（不包括双引号）
Goal: Try to find the Key of user "KCTF"

如果看到Game Over说明你的Key是错的。
If you see Game Over, your key is incorrect.

如果输出中有You Win!，那么你成功地找到了正确答案。
If you see You Win! in the output, you have successfully found the right answer.
