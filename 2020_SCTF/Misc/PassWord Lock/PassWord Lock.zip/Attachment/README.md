这有一个stm32f103c8t6主控的密码锁, 它有4个按键分别为1, 2, 3, 4. 分别对应GPIO_PA1, GPIO_PA2, GPIO_PA3, GPIO_PA4.flag格式为SCTF{正确的按键密码}

提示: 中断向量表, 芯片数据手册

```
This has a stm32f103c8t6 mcu password lock, it has 4 keys respectively 1, 2, 3, 4. Corresponding to GPIO_PA1, GPIO_PA2, GPIO_PA3, GPIO_PA4.
The flag format is SCTF{The correct password}

Tip: Physicalremap and chip datasheet.
```


