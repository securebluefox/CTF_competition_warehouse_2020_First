#!/bin/bash
cd /home/ctf
exec timeout 600 qemu-system-x86_64 \
    -m 128 \
    -nographic \
    -kernel ./bzImage \
    -append 'console=ttyS0 loglevel=3 oops=panic panic=1 nokaslr' \
    -monitor /dev/null \
    -initrd initramfs.cpio  \
    -enable-kvm \
    -smp 4 \
    -cpu host,smep,smap
