Baby LLVM

Env:
Ubuntu 19.04
LLVM version 8.0.0

Once .bc file uploaded, remote will execute `opt-8 -load BabyPass.so -BabyPass ${bc_file} `
