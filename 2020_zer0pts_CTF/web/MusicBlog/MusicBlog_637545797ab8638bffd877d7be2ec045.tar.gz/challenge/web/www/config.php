<?php
define('DB_DSN', 'mysql:dbname=app;host=mysql');
define('DB_USERNAME', 'user');
define('DB_PASSWORD', '<censored>');